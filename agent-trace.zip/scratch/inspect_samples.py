import pandas as pd
import json

df = pd.read_csv('dataset/sample_output.csv')
for _, row in df.iterrows():
    steps = json.loads(row['steps_json'])
    print(f"=== {row['case_id']}: {row['deletion_status']} ({len(steps)} steps) ===")
    for s in steps:
        print(f"  Step {s.get('step_no')}: {s.get('phase')} | {s.get('system_id')} | {s.get('resource_id')} | {s.get('operation')} | {s.get('state')} | ev={s.get('evidence_id')}")
